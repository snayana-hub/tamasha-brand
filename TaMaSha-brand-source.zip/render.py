import cairosvg, sys, os
def png(src, dst, w=None, bg=None):
    kw={}
    if w: kw['output_width']=w
    if bg: kw['background_color']=bg
    cairosvg.svg2png(url=src, write_to=dst, **kw)
    print('->',dst)
if __name__=='__main__':
    png(sys.argv[1], sys.argv[2], int(sys.argv[3]) if len(sys.argv)>3 else None,
        sys.argv[4] if len(sys.argv)>4 else None)
