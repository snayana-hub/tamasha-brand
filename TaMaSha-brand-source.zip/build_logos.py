import wm, os

# ---------- Brand palette ----------
BORDEAUX  = "#5E1B25"   # primary dark red
WINE      = "#2B0E12"   # deep wine (dark bg)
GOLD      = "#BFA05A"   # antique gold accent
CHAMPAGNE = "#E3CE9B"   # light gold
CREAM     = "#F4EBDB"   # cream background
ESPRESSO  = "#2A201C"   # neutral text

FONTS = {
    'cormorant': 'fonts/Cormorant-SemiBold.ttf',
    'playfair':  'fonts/Playfair-SemiBold.ttf',
    'cinzel':    'fonts/Cinzel-SemiBold.ttf',
}

def wordmark_svg(font_key, letter_color, bar_color, tracking=0.07,
                 bg=None, pad=140, bar_gap=78, bar_h=46, bar_wscale=1.02,
                 text='TaMaSha', bars_on=('a',), extra_defs='', letter_fill_attr=None):
    L = wm.layout(text, FONTS[font_key], tracking)
    ps = L['paths']; xh=L['xheight']
    xs=[]; 
    minx=1e9; maxx=-1e9; miny=1e9; maxy=-1e9
    for p in ps:
        if p['bounds']:
            b=p['bounds']
            minx=min(minx,p['x']+b[0]); maxx=max(maxx,p['x']+b[2])
            miny=min(miny,b[1]); maxy=max(maxy,b[3])
    # bar band
    bar_bottom = xh + bar_gap
    bar_top = bar_bottom + bar_h
    top = max(maxy, bar_top)
    bot = miny
    W = (maxx-minx) + 2*pad
    H = (top-bot) + 2*pad
    # group flips y: user y-down. place so that content maps into [pad, pad+..]
    # world point (X,Y_up) -> svg: sx = X - minx + pad ; sy = (top - Y) + pad
    def gtag():
        return f'<g transform="translate({pad - minx}, {pad + top}) scale(1,-1)">'
    parts=[]
    if bg:
        parts.append(f'<rect x="0" y="0" width="{W:.1f}" height="{H:.1f}" fill="{bg}"/>')
    parts.append(gtag())
    fillattr = letter_fill_attr if letter_fill_attr else f'fill="{letter_color}"'
    for p in ps:
        if p['d']:
            parts.append(f'<path transform="translate({p["x"]:.2f},0)" d="{p["d"]}" {fillattr}/>')
    # macron bars
    r = bar_h/2
    for p in ps:
        if p['char'] in bars_on and p['bounds']:
            b=p['bounds']; cx=p['x']+(b[0]+b[2])/2; w=(b[2]-b[0])*bar_wscale
            parts.append(f'<rect x="{cx-w/2:.2f}" y="{bar_bottom:.2f}" width="{w:.2f}" height="{bar_h}" rx="{r:.1f}" ry="{r:.1f}" fill="{bar_color}"/>')
    parts.append('</g>')
    svg=(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W:.1f} {H:.1f}" width="{W:.1f}" height="{H:.1f}">'
         f'{extra_defs}'+''.join(parts)+'</svg>')
    return svg, W, H

os.makedirs('svg', exist_ok=True)
def save(name, svg):
    open(f'svg/{name}.svg','w').write(svg); print('wrote', name, len(svg))

# Concepts (3 type directions)
save('concept_cormorant', wordmark_svg('cormorant', BORDEAUX, GOLD)[0])
save('concept_playfair',  wordmark_svg('playfair',  BORDEAUX, GOLD)[0])
save('concept_cinzel',    wordmark_svg('cinzel',    BORDEAUX, GOLD, tracking=0.12, bars_on=('a','A'), text='TAMASHA')[0])

# PRIMARY (Cormorant) - bordeaux letters, gold bars, transparent
save('logo_primary',      wordmark_svg('cormorant', BORDEAUX, GOLD)[0])
# Mono gold
save('logo_mono_gold',    wordmark_svg('cormorant', GOLD, GOLD)[0])
# Mono bordeaux
save('logo_mono_bordeaux',wordmark_svg('cormorant', BORDEAUX, BORDEAUX)[0])
# On dark (cream letters + gold bars) with wine bg for preview
save('logo_on_dark',      wordmark_svg('cormorant', CREAM, GOLD, bg=WINE)[0])
# On cream (bordeaux + gold) with cream bg
save('logo_on_cream',     wordmark_svg('cormorant', BORDEAUX, GOLD, bg=CREAM)[0])
# Reverse cream mono on transparent (for dark placements)
save('logo_rev_cream',    wordmark_svg('cormorant', CREAM, CHAMPAGNE)[0])
print("done")
