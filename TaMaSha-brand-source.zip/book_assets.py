import base64
def b64(path):
    return base64.b64encode(open(path,'rb').read()).decode()
def font_face(name,path,weight="400",style="normal"):
    return f"""@font-face{{font-family:'{name}';font-weight:{weight};font-style:{style};src:url(data:font/ttf;base64,{b64(path)}) format('truetype');}}"""
FONTS = "".join([
    font_face("Cormorant","fonts/Cormorant-Medium.ttf","500"),
    font_face("Cormorant","fonts/Cormorant-SemiBold.ttf","600"),
    font_face("Playfair","fonts/Playfair-SemiBold.ttf","600"),
    font_face("Cinzel","fonts/Cinzel-SemiBold.ttf","600"),
    font_face("Jost","fonts/Jost-Regular.ttf","400"),
    font_face("Jost","fonts/Jost-Medium.ttf","500"),
])
def img(path): 
    return f"data:image/png;base64,{b64(path)}"
