import wm, t2p, os
BORDEAUX="#5E1B25"; WINE="#2B0E12"; GOLD="#BFA05A"; CHAMPAGNE="#E3CE9B"; CREAM="#F4EBDB"
CORM='fonts/Cormorant-SemiBold.ttf'; CINZ='fonts/Cinzel-SemiBold.ttf'; JOST='fonts/Jost-Medium.ttf'
os.makedirs('svg',exist_ok=True)
def save(n,s): open(f'svg/{n}.svg','w').write(s); print('wrote',n)

def centered_line(text,font,size,tracking,fill,cx,baseline):
    tp=t2p.text_paths(text,font,size,tracking,fill)
    return f'<g transform="translate({cx-tp["width"]/2:.2f},{baseline:.2f})">{tp["svg"]}</g>', tp['width']

# ---------- ICON A: medallion with three graduated bars (macron motif) ----------
def medallion(ring_color, fill_color, bar_color, text_color, size=600):
    c=size/2; r=c-6
    parts=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {size} {size}" width="{size}" height="{size}">']
    if fill_color:
        parts.append(f'<circle cx="{c}" cy="{c}" r="{r}" fill="{fill_color}"/>')
    parts.append(f'<circle cx="{c}" cy="{c}" r="{r}" fill="none" stroke="{ring_color}" stroke-width="4"/>')
    parts.append(f'<circle cx="{c}" cy="{c}" r="{r-14}" fill="none" stroke="{ring_color}" stroke-width="1.6"/>')
    # three graduated bars centered, upper-middle
    barh=size*0.032; gap=size*0.05; widths=[size*0.30,size*0.22,size*0.14]
    top=size*0.30
    for i,w in enumerate(widths):
        y=top+i*(barh+gap)
        parts.append(f'<rect x="{c-w/2:.1f}" y="{y:.1f}" width="{w:.1f}" height="{barh:.1f}" rx="{barh/2:.1f}" fill="{bar_color}"/>')
    # wordmark microtype
    g,_=centered_line('TAMASHA',CINZ,size*0.088,0.18,text_color,c,size*0.70)
    parts.append(g)
    g2,_=centered_line('HYDERABAD',JOST,size*0.040,0.42,text_color,c,size*0.80)
    parts.append(g2)
    parts.append('</svg>')
    return ''.join(parts)

save('icon_medallion',        medallion(GOLD, BORDEAUX, GOLD, CREAM))
save('icon_medallion_gold',   medallion(GOLD, WINE, GOLD, GOLD))
save('icon_medallion_cream',  medallion(GOLD, "none", GOLD, CREAM))  # on-dark use

# ---------- ICON B: monogram T with macron (ā signature on the T) ----------
def monogram(fill_color, letter_color, bar_color, size=600):
    c=size/2; r=c-6
    parts=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {size} {size}" width="{size}" height="{size}">']
    if fill_color: parts.append(f'<circle cx="{c}" cy="{c}" r="{r}" fill="{fill_color}"/>')
    parts.append(f'<circle cx="{c}" cy="{c}" r="{r}" fill="none" stroke="{bar_color}" stroke-width="3"/>')
    tp=t2p.text_paths('T',CORM,size*0.62,0,letter_color)
    tx=c-tp['width']/2; base=c+tp['cap']*0.5
    parts.append(f'<g transform="translate({tx:.2f},{base:.2f})">{tp["svg"]}</g>')
    # macron bar above the T
    bw=tp['width']*1.15; bh=size*0.035
    parts.append(f'<rect x="{c-bw/2:.1f}" y="{base-tp["cap"]-size*0.075:.1f}" width="{bw:.1f}" height="{bh:.1f}" rx="{bh/2:.1f}" fill="{bar_color}"/>')
    parts.append('</svg>')
    return ''.join(parts)
save('icon_monogram', monogram(BORDEAUX, CREAM, GOLD))
save('icon_monogram_gold', monogram(WINE, GOLD, GOLD))

# ---------- PRIMARY LOCKUP: wordmark + rule + descriptor ----------
def lockup(letter_color, bar_color, desc_color, rule_color, bg=None, text='TaMaSha'):
    from build_logos import wordmark_svg  # reuse
    # build wordmark group manually here for placement
    L=wm.layout(text,CORM,0.07); ps=L['paths']; xh=L['xheight']
    minx=1e9;maxx=-1e9;miny=1e9;maxy=-1e9
    for p in ps:
        if p['bounds']:
            b=p['bounds']; minx=min(minx,p['x']+b[0]); maxx=max(maxx,p['x']+b[2]); miny=min(miny,b[1]); maxy=max(maxy,b[3])
    s=0.42  # scale font units -> px
    wm_w=(maxx-minx)*s
    bar_bottom=xh+78; bar_top=bar_bottom+46; top=max(maxy,bar_top)
    pad=90
    # canvas
    desc="PURE  VEG   ·   ASIAN  KITCHEN"
    tpd=t2p.text_paths(desc,JOST,44,0.30,desc_color)
    W=max(wm_w, tpd['width'])+2*pad
    wm_h=(top-miny)*s
    rule_gap=46; desc_gap=40
    H=pad+wm_h+rule_gap+desc_gap+50+pad
    cx=W/2
    parts=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W:.1f} {H:.1f}" width="{W:.1f}" height="{H:.1f}">']
    if bg: parts.append(f'<rect width="{W:.1f}" height="{H:.1f}" fill="{bg}"/>')
    # wordmark: place baseline. world Y_up -> svg y = pad + (top - Y)*s ; x = pad + (X-minx)*s + (W-2pad-wm_w)/2
    offx=pad+(W-2*pad-wm_w)/2 - minx*s
    gy=pad+top*s
    parts.append(f'<g transform="translate({offx:.2f},{gy:.2f}) scale({s},{-s})">')
    for p in ps:
        if p['d']: parts.append(f'<path transform="translate({p["x"]:.2f},0)" d="{p["d"]}" fill="{letter_color}"/>')
    r=23
    for p in ps:
        if p['char']=='a' and p['bounds']:
            b=p['bounds']; ccx=p['x']+(b[0]+b[2])/2; w=(b[2]-b[0])*1.02
            parts.append(f'<rect x="{ccx-w/2:.2f}" y="{bar_bottom:.2f}" width="{w:.2f}" height="46" rx="23" fill="{bar_color}"/>')
    parts.append('</g>')
    ry=pad+wm_h+rule_gap
    # rule with center diamond
    rw=wm_w*0.9
    parts.append(f'<line x1="{cx-rw/2:.1f}" y1="{ry:.1f}" x2="{cx-40:.1f}" y2="{ry:.1f}" stroke="{rule_color}" stroke-width="2"/>')
    parts.append(f'<line x1="{cx+40:.1f}" y1="{ry:.1f}" x2="{cx+rw/2:.1f}" y2="{ry:.1f}" stroke="{rule_color}" stroke-width="2"/>')
    parts.append(f'<rect x="{cx-7:.1f}" y="{ry-7:.1f}" width="14" height="14" transform="rotate(45 {cx:.1f} {ry:.1f})" fill="{rule_color}"/>')
    dby=ry+desc_gap+tpd['cap']
    parts.append(f'<g transform="translate({cx-tpd["width"]/2:.2f},{dby:.2f})">{tpd["svg"]}</g>')
    parts.append('</svg>')
    return ''.join(parts)

save('lockup_primary', lockup(BORDEAUX,GOLD,BORDEAUX,GOLD))
save('lockup_on_dark', lockup(CREAM,GOLD,CHAMPAGNE,GOLD,bg=WINE))
save('lockup_on_cream',lockup(BORDEAUX,GOLD,BORDEAUX,GOLD,bg=CREAM))
print('done')
