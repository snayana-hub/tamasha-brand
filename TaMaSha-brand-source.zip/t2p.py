# Generic text -> SVG path group. Baseline at y=0, first glyph origin x=0. y-down output.
import wm
_cache={}
def _layout(text,font,tracking):
    key=(text,font,tracking)
    if key not in _cache: _cache[key]=wm.layout(text,font,tracking)
    return _cache[key]
def text_paths(text, font, size, tracking=0.0, fill="#000", weight_paths=None):
    L=_layout(text,font,tracking); s=size/L['upem']
    parts=[]
    for p in L['paths']:
        if p['d']:
            parts.append(f'<path transform="matrix({s:.5f},0,0,{-s:.5f},{p["x"]*s:.3f},0)" d="{p["d"]}" fill="{fill}"/>')
    return {'svg':''.join(parts),'width':L['width']*s,'cap':L['cap']*s,
            'ascent':L['ascent']*s,'xheight':L['xheight']*s,'layout':L,'s':s}
