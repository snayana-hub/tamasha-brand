from book_assets import FONTS, img

BORDEAUX="#5E1B25"; WINE="#2B0E12"; GOLD="#BFA05A"; CHAMPAGNE="#E3CE9B"; CREAM="#F4EBDB"; ESPRESSO="#2A201C"
PAPER="#FBF6EC"

# preload images
I = {
 'lockup_dark': img('png/lockup_on_dark.png'),
 'primary': img('exports/png/TaMaSha-logo-primary-2048w.png'),
 'mono_gold': img('exports/png/TaMaSha-logo-mono-gold-2048w.png'),
 'rev_cream': img('png/logo_rev_cream.png'),
 'lockup': img('exports/png/TaMaSha-logo-lockup-2048w.png'),
 'medallion': img('exports/png/TaMaSha-icon-medallion-1024w.png'),
 'medallion_cream': img('svg/icon_medallion_cream.svg') if False else img('png/icon_medallion.png'),
 'monogram': img('exports/png/TaMaSha-icon-monogram-1024w.png'),
}
import cairosvg
cairosvg.svg2png(url='svg/icon_medallion_cream.svg', write_to='png/icon_medallion_cream.png', output_width=1024)
I['medallion_cream']=img('png/icon_medallion_cream.png')
cairosvg.svg2png(url='svg/icon_monogram_gold.svg', write_to='png/icon_monogram_gold.png', output_width=1024)
I['monogram_gold']=img('png/icon_monogram_gold.png')

CSS = f"""
{FONTS}
*{{margin:0;padding:0;box-sizing:border-box;}}
@page{{size:297mm 210mm;margin:0;}}
html,body{{-webkit-print-color-adjust:exact;print-color-adjust:exact;}}
body{{font-family:'Jost',sans-serif;color:{ESPRESSO};}}
.page{{width:297mm;height:210mm;position:relative;overflow:hidden;page-break-after:always;background:{PAPER};}}
.page:last-child{{page-break-after:auto;}}
.pad{{position:absolute;inset:20mm 22mm;}}
.serif{{font-family:'Cormorant',serif;}}
.disp{{font-family:'Cormorant',serif;font-weight:600;}}
.cinz{{font-family:'Cinzel',serif;font-weight:600;}}
.kick{{font-family:'Jost';font-weight:500;letter-spacing:.42em;text-transform:uppercase;font-size:9.5pt;color:{GOLD};}}
.pnum{{position:absolute;bottom:11mm;right:22mm;font-size:8pt;letter-spacing:.3em;color:{BORDEAUX};opacity:.7;}}
.pttl{{position:absolute;bottom:11mm;left:22mm;font-size:8pt;letter-spacing:.3em;color:{BORDEAUX};opacity:.7;text-transform:uppercase;}}
h1.sec{{font-family:'Cormorant',serif;font-weight:600;font-size:40pt;color:{BORDEAUX};line-height:1;margin:6mm 0 4mm;}}
p.lead{{font-family:'Cormorant',serif;font-weight:500;font-size:16pt;line-height:1.5;color:{ESPRESSO};max-width:150mm;}}
p.body{{font-size:10.5pt;line-height:1.75;color:#4a3b33;max-width:150mm;}}
.rule{{height:1px;background:{GOLD};opacity:.6;width:100%;}}
.diamond{{width:7px;height:7px;background:{GOLD};transform:rotate(45deg);display:inline-block;margin:0 8px;vertical-align:middle;}}
.tag{{font-family:'Jost';font-weight:500;letter-spacing:.3em;text-transform:uppercase;font-size:8pt;}}
"""

def page(inner, cls="", style=""):
    return f'<div class="page {cls}" style="{style}">{inner}</div>'

pages=[]

# 1 COVER
pages.append(page(f"""
<div style="position:absolute;inset:0;background:{WINE};"></div>
<div style="position:absolute;inset:9mm;border:1px solid {GOLD};opacity:.55;"></div>
<div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;">
  <div class="cinz" style="color:{GOLD};letter-spacing:.55em;font-size:11pt;margin-bottom:8mm;">HYDERABAD &nbsp;&middot;&nbsp; PURE VEG ASIAN KITCHEN</div>
  <img src="{I['lockup_dark']}" style="width:150mm;"/>
  <div style="margin-top:12mm;text-align:center;">
    <div class="disp" style="color:{CREAM};font-size:26pt;letter-spacing:.02em;">Brand Book</div>
    <div class="tag" style="color:{CHAMPAGNE};margin-top:4mm;">Visual Identity Guidelines &nbsp;·&nbsp; Version 1.0</div>
  </div>
</div>
""")) 

# 2 CONTENTS
toc=[("01","The Brand"),("02","Logo · The Signature"),("03","Logo Variations"),("04","Clear Space & Minimum Size"),
     ("05","Logo Don'ts"),("06","Colour Palette"),("07","Typography"),("08","Voice, Tone & Tagline"),
     ("09","Look & Feel"),("10","Dos & Don'ts")]
rows="".join([f'<div style="display:flex;align-items:baseline;gap:10mm;padding:3.1mm 0;border-bottom:1px solid rgba(94,27,37,.12);"><span class="cinz" style="color:{GOLD};font-size:12pt;width:14mm;">{n}</span><span class="serif" style="font-weight:600;font-size:17pt;color:{BORDEAUX};">{t}</span></div>' for n,t in toc])
pages.append(page(f"""<div class="pad">
  <div class="kick">TaMaSha · Brand Book</div>
  <h1 class="sec">Contents</h1>
  <div style="margin-top:6mm;max-width:170mm;">{rows}</div>
  <img src="{I['monogram']}" style="position:absolute;right:0;bottom:0;width:52mm;opacity:.9;"/>
</div><div class="pttl">TaMaSha Brand Book</div><div class="pnum">02</div>""")) 

# 3 THE BRAND
facts=[("Concept","100% pure-vegetarian Asian restro-café"),
       ("Cuisine","Korean, Thai, Indo-Chinese & pan-Asian, with specialty coffee"),
       ("Signature dishes","Ramen · Kimchi · Gyoza · Brownies"),
       ("Location","Jubilee Hills, Hyderabad (+ Gunrock)"),
       ("Positioning","Premium, elegant fine-dining")]
fr="".join([f'<div style="padding:3mm 0;border-bottom:1px solid rgba(94,27,37,.12);"><div class="tag" style="color:{GOLD};">{k}</div><div class="serif" style="font-weight:500;font-size:13.5pt;color:{ESPRESSO};margin-top:1mm;">{v}</div></div>' for k,v in facts])
pages.append(page(f"""<div class="pad">
  <div class="kick">01 · The Brand</div>
  <h1 class="sec">A quiet drama,<br/>plated.</h1>
  <p class="lead">TaMaSha means spectacle - a joyful commotion. We serve it without a single note of meat: a pure-vegetarian Asian kitchen where Korea, Thailand and the Far East meet Hyderabad, poured over great coffee and set in calm, considered surroundings.</p>
  <div style="display:flex;gap:16mm;margin-top:9mm;">
    <div style="flex:1;">{fr}</div>
    <div style="width:62mm;display:flex;align-items:center;justify-content:center;"><img src="{I['medallion']}" style="width:60mm;"/></div>
  </div>
</div><div class="pttl">The Brand</div><div class="pnum">03</div>""")) 

# 4 LOGO SIGNATURE
pages.append(page(f"""<div class="pad">
  <div class="kick">02 · Logo · The Signature</div>
  <h1 class="sec">The wordmark</h1>
  <div style="background:{PAPER};border:1px solid rgba(191,160,90,.5);padding:18mm 10mm;display:flex;justify-content:center;margin-top:2mm;">
     <img src="{I['primary']}" style="width:180mm;"/>
  </div>
  <div style="display:flex;gap:14mm;margin-top:8mm;">
    <p class="body" style="flex:1;">The TaMaSha wordmark is set in a high-contrast Cormorant Garamond, refined for a fine-dining register. The alternating capitals - <b>T</b>a<b>M</b>a<b>S</b>ha - give the name its rhythm.</p>
    <p class="body" style="flex:1;">The <b>signature element</b> is the gold bar - a macron (ā) - set over every lowercase <span class="serif" style="font-weight:600;">a</span>. Three bars, evenly weighted, become an ownable mark: elegant, deliberate, unmistakably TaMaSha. Always keep the bars gold and level.</p>
  </div>
</div><div class="pttl">Logo</div><div class="pnum">04</div>""")) 

# 5 VARIATIONS
def tile(imgsrc,bg,label,w="66mm"):
    return f'<div style="background:{bg};border:1px solid rgba(94,27,37,.14);height:52mm;display:flex;align-items:center;justify-content:center;padding:7mm;"><img src="{imgsrc}" style="max-width:{w};max-height:34mm;"/></div><div class="tag" style="color:{BORDEAUX};margin:2.5mm 0 0;">{label}</div>'
grid=f"""<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8mm 8mm;margin-top:4mm;">
 <div>{tile(I['primary'],PAPER,'Primary — Bordeaux + Gold')}</div>
 <div>{tile(I['mono_gold'],PAPER,'Mono — Gold')}</div>
 <div>{tile(I['rev_cream'],WINE,'Reverse — On Dark')}</div>
 <div>{tile(I['medallion'],PAPER,'Medallion — Emblem')}</div>
 <div>{tile(I['monogram'],PAPER,'Monogram — T + macron')}</div>
 <div>{tile(I['medallion_cream'],WINE,'Emblem — On Dark')}</div>
</div>"""
pages.append(page(f"""<div class="pad">
  <div class="kick">03 · Logo Variations</div>
  <h1 class="sec">Variations</h1>
  {grid}
</div><div class="pttl">Logo Variations</div><div class="pnum">05</div>""")) 

# 6 CLEAR SPACE
pages.append(page(f"""<div class="pad">
  <div class="kick">04 · Clear Space & Minimum Size</div>
  <h1 class="sec">Room to breathe</h1>
  <div style="display:flex;gap:14mm;margin-top:3mm;">
    <div style="flex:1.3;">
      <div style="position:relative;background:{PAPER};border:1px solid rgba(94,27,37,.14);padding:22mm;">
        <div style="position:absolute;inset:9mm;border:1px dashed {GOLD};"></div>
        <img src="{I['primary']}" style="width:100%;position:relative;"/>
      </div>
      <p class="body" style="margin-top:4mm;">Keep clear space on all sides equal to the height of the capital <span class="serif" style="font-weight:600;">T</span>. Never crowd the wordmark with other type, graphics or edges.</p>
    </div>
    <div style="flex:1;">
      <div style="background:{PAPER};border:1px solid rgba(94,27,37,.14);padding:10mm;display:flex;flex-direction:column;gap:9mm;align-items:flex-start;">
        <div><img src="{I['primary']}" style="width:70mm;"/><div class="tag" style="color:{BORDEAUX};margin-top:3mm;">Digital — min 140 px wide</div></div>
        <div><img src="{I['primary']}" style="width:34mm;"/><div class="tag" style="color:{BORDEAUX};margin-top:3mm;">Print — min 28 mm wide</div></div>
        <div><img src="{I['monogram']}" style="width:16mm;"/><div class="tag" style="color:{BORDEAUX};margin-top:3mm;">Below that — use the monogram</div></div>
      </div>
    </div>
  </div>
</div><div class="pttl">Clear Space</div><div class="pnum">06</div>""")) 

# 7 DON'TS
def dont(imgsrc,txt,extra=""):
    return f"""<div><div style="position:relative;background:{PAPER};border:1px solid rgba(94,27,37,.14);height:42mm;display:flex;align-items:center;justify-content:center;padding:6mm;overflow:hidden;">{extra}<img src="{imgsrc}" style="max-width:58mm;max-height:26mm;"/><div style="position:absolute;top:3mm;right:3mm;width:7mm;height:7mm;border-radius:50%;background:{BORDEAUX};color:{CREAM};font-size:11pt;line-height:7mm;text-align:center;">✕</div></div><div class="tag" style="color:{BORDEAUX};margin-top:2.5mm;">{txt}</div></div>"""
donts=f"""<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:7mm;margin-top:4mm;">
 {dont(I['primary'],"Don't stretch or distort",'<style></style>')}
 {dont(I['primary'],"Don't recolour outside the palette",f'<div style="position:absolute;inset:0;background:#1c6b3a;opacity:.9;"></div>')}
 {dont(I['primary'],"Don't rotate the wordmark",'')}
 {dont(I['primary'],"Don't remove the gold bars",'')}
 {dont(I['rev_cream'],"Don't place light logo on busy light photos",f'<div style="position:absolute;inset:0;background:linear-gradient(45deg,#ddd,#bbb);"></div>')}
 {dont(I['primary'],"Don't add shadows or effects",'')}
</div>"""
pages.append(page(f"""<div class="pad">
  <div class="kick">05 · Logo Don'ts</div>
  <h1 class="sec">Please don't</h1>
  {donts}
</div><div class="pttl">Logo Don'ts</div><div class="pnum">07</div>""")) 

# 8 COLOUR
def sw(name,hexv,role,dark=False):
    tc = CREAM if dark else "#fff"
    txt = "#3a2b23" 
    return f"""<div style="flex:1;"><div style="background:{hexv};height:58mm;border:1px solid rgba(0,0,0,.08);position:relative;"><span style="position:absolute;bottom:4mm;left:4mm;font-family:'Jost';font-weight:500;font-size:8.5pt;letter-spacing:.12em;color:{'#F4EBDB' if dark else '#3a2b23'};">{hexv.upper()}</span></div><div class="serif" style="font-weight:600;font-size:13pt;color:{BORDEAUX};margin-top:3mm;">{name}</div><div class="tag" style="color:#8a7a70;margin-top:1mm;">{role}</div></div>"""
swatches=f"""<div style="display:flex;gap:5mm;margin-top:5mm;">
 {sw('Bordeaux',BORDEAUX,'Primary',True)}
 {sw('Deep Wine',WINE,'Dark background',True)}
 {sw('Antique Gold',GOLD,'Accent')}
 {sw('Champagne',CHAMPAGNE,'Light accent')}
 {sw('Cream',CREAM,'Background')}
 {sw('Espresso',ESPRESSO,'Neutral text',True)}
</div>"""
pages.append(page(f"""<div class="pad">
  <div class="kick">06 · Colour Palette</div>
  <h1 class="sec">Colour</h1>
  <p class="body">Dark red, cream and gold - warm, restrained and unmistakably premium. Bordeaux and Cream carry most surfaces; Gold is reserved for the signature bars, keylines and small marks. Never let gold dominate.</p>
  {swatches}
  <div style="display:flex;gap:8mm;margin-top:7mm;">
    <div class="body" style="flex:1;"><b style="color:{BORDEAUX}">Print / CMYK & Pantone</b> should be matched from these HEX values at production; gold may be produced as a metallic (approx. Pantone 871 C) for premium collateral.</div>
    <div class="body" style="flex:1;"><b style="color:{BORDEAUX}">Contrast</b> — use Cream or Champagne text on Bordeaux/Wine; Espresso or Bordeaux text on Cream. Keep body text off pure gold.</div>
  </div>
</div><div class="pttl">Colour</div><div class="pnum">08</div>""")) 

# 9 TYPOGRAPHY
pages.append(page(f"""<div class="pad">
  <div class="kick">07 · Typography</div>
  <h1 class="sec">Typography</h1>
  <div style="display:flex;gap:14mm;margin-top:2mm;">
    <div style="flex:1;">
      <div class="tag" style="color:{GOLD};">Display / Headlines</div>
      <div class="disp" style="font-size:52pt;color:{BORDEAUX};line-height:1;margin-top:2mm;">Cormorant<br/>Garamond</div>
      <div class="serif" style="font-weight:500;font-size:13pt;color:#4a3b33;margin-top:4mm;">A a B b · Ramen · Kimchi · Gyoza<br/>1234567890</div>
      <p class="body" style="margin-top:4mm;">High-contrast, literary and elegant. Used for the name, menu headings and large statements. Set generously, with air.</p>
    </div>
    <div style="flex:1;">
      <div class="tag" style="color:{GOLD};">Text / UI / Captions</div>
      <div style="font-family:'Jost';font-weight:500;font-size:34pt;color:{BORDEAUX};line-height:1.05;margin-top:2mm;">Jost</div>
      <div style="font-family:'Jost';font-size:12pt;color:#4a3b33;margin-top:4mm;letter-spacing:.02em;">A a B b · Pure Veg Asian Kitchen<br/>1234567890</div>
      <p class="body" style="margin-top:4mm;">A calm geometric sans for body copy, labels and wayfinding. Use Medium for labels (letter-spaced, uppercase) and Regular for running text.</p>
      <div style="margin-top:6mm;border-top:1px solid rgba(94,27,37,.15);padding-top:4mm;">
        <div class="tag" style="color:{BORDEAUX};">Pairing rule</div>
        <p class="body">Cormorant for voice &amp; occasion · Jost for clarity &amp; information.</p>
      </div>
    </div>
  </div>
</div><div class="pttl">Typography</div><div class="pnum">09</div>""")) 

# 10 VOICE + TAGLINE
tags=["A quiet drama, plated.","Pure veg. Pure Asian. Pure theatre.","Vegetarian, without compromise.","The spectacle of vegetarian Asian."]
tl="".join([f'<div style="padding:3mm 0;border-bottom:1px solid rgba(94,27,37,.12);"><span class="serif" style="font-weight:600;font-size:19pt;color:{BORDEAUX};">"{t}"</span></div>' for t in tags])
pages.append(page(f"""<div class="pad">
  <div class="kick">08 · Voice, Tone & Tagline</div>
  <h1 class="sec">How we speak</h1>
  <div style="display:flex;gap:14mm;margin-top:2mm;">
   <div style="flex:1;">
     <p class="body"><b style="color:{BORDEAUX}">Voice</b> — warm, confident, quietly theatrical. We host; we don't shout. We celebrate vegetables and Asian craft without lecturing.</p>
     <p class="body" style="margin-top:4mm;"><b style="color:{BORDEAUX}">Tone</b> — elegant and generous in hospitality; crisp and precise in information. Sentences are short and unfussy.</p>
     <div style="margin-top:5mm;display:flex;gap:8mm;">
       <div class="body" style="flex:1;"><span class="tag" style="color:{GOLD}">We are</span><br/>Refined · Warm · Playful · Assured</div>
       <div class="body" style="flex:1;"><span class="tag" style="color:{GOLD}">We are not</span><br/>Loud · Preachy · Trendy-chasing · Casual</div>
     </div>
   </div>
   <div style="flex:1;">
     <div class="tag" style="color:{GOLD};margin-bottom:2mm;">Tagline directions</div>
     {tl}
     <p class="body" style="margin-top:4mm;font-style:italic;">Primary recommendation: "A quiet drama, plated."</p>
   </div>
  </div>
</div><div class="pttl">Voice & Tone</div><div class="pnum">10</div>""")) 

# 11 LOOK & FEEL
pages.append(page(f"""
<div style="position:absolute;inset:0;background:{WINE};"></div>
<div class="pad" style="inset:18mm 20mm;">
 <div class="kick" style="color:{GOLD};">09 · Look & Feel</div>
 <h1 class="sec" style="color:{CREAM};">Mood</h1>
 <div style="display:grid;grid-template-columns:repeat(4,1fr);grid-auto-rows:34mm;gap:6mm;margin-top:3mm;">
   <div style="background:{BORDEAUX};"></div>
   <div style="background:{GOLD};"></div>
   <div style="background:{CREAM};display:flex;align-items:center;justify-content:center;"><img src="{I['monogram']}" style="width:26mm;"/></div>
   <div style="background:{CHAMPAGNE};"></div>
   <div style="grid-column:span 2;background:{BORDEAUX};display:flex;align-items:center;justify-content:center;"><img src="{I['rev_cream']}" style="width:78mm;"/></div>
   <div style="background:{GOLD};"></div>
   <div style="background:{CREAM};"></div>
 </div>
 <p class="body" style="color:{CHAMPAGNE};margin-top:6mm;max-width:180mm;">Candlight warmth on deep wine walls. Brushed gold, linen and dark timber. Steam rising off ceramic bowls. Generous negative space, low light, considered detail - fine dining that happens to be entirely vegetarian.</p>
</div><div class="pttl" style="color:{CHAMPAGNE};">Look & Feel</div><div class="pnum" style="color:{CHAMPAGNE};">11</div>""")) 

# 12 DOS & DON'TS
dos=["Lead with Bordeaux &amp; Cream; use Gold sparingly","Keep the three gold bars level and gold","Give the logo generous clear space","Pair Cormorant with Jost","Photograph food warm, close and calm"]
dnt=["Don't recolour or add effects to the logo","Don't let gold dominate a layout","Don't crowd or shrink the wordmark past minimums","Don't mix in unrelated typefaces","Don't imply anything non-vegetarian"]
def li(items,color,mark):
    return "".join([f'<div style="display:flex;gap:5mm;padding:2.6mm 0;border-bottom:1px solid rgba(94,27,37,.1);"><span style="color:{color};font-weight:600;">{mark}</span><span class="body" style="max-width:none;">{t}</span></div>' for t in items])
pages.append(page(f"""<div class="pad">
  <div class="kick">10 · Dos & Don'ts</div>
  <h1 class="sec">In short</h1>
  <div style="display:flex;gap:16mm;margin-top:3mm;">
   <div style="flex:1;"><div class="tag" style="color:{GOLD};margin-bottom:2mm;">Do</div>{li(dos,'#4a7a4a','✓')}</div>
   <div style="flex:1;"><div class="tag" style="color:{GOLD};margin-bottom:2mm;">Don't</div>{li(dnt,BORDEAUX,'✕')}</div>
  </div>
  <div style="position:absolute;left:22mm;right:22mm;bottom:16mm;display:flex;align-items:center;justify-content:space-between;">
    <img src="{I['monogram']}" style="width:22mm;"/>
    <div class="tag" style="color:{BORDEAUX};">TaMaSha · Pure Veg Asian Kitchen · Hyderabad · Brand Book v1.0</div>
  </div>
</div><div class="pttl">Dos & Don'ts</div><div class="pnum">12</div>""")) 

html=f"<!doctype html><html><head><meta charset='utf-8'><style>{CSS}</style></head><body>{''.join(pages)}</body></html>"
open('brandbook.html','w').write(html)
print("wrote brandbook.html", len(html), "pages", len(pages))
