# -*- coding: utf-8 -*-
import re
s=open('build_book.py').read()

anchor="I['monogram_gold']=img('png/icon_monogram_gold.png')"
add=anchor+"\nI['ta']=img('png/syll_ta.png')\nI['ma']=img('png/syll_ma.png')\nI['sha']=img('png/syll_sha.png')"
s=s.replace(anchor,add,1)

new_toc=('toc=[("01","The Brand"),("02","The Name"),("03","Logo \u00b7 The Signature"),("04","Logo Variations"),'
 '("05","Clear Space & Minimum Size"),("06","Logo Don\'ts"),("07","Colour Palette"),("08","Typography"),'
 '("09","Voice, Tone & Tagline"),("10","Look & Feel"),("11","Dos & Don\'ts")]\n')
s=re.sub(r"toc=\[.*?\]\n", lambda m:new_toc, s, count=1, flags=re.S)

def kick_repl(m):
    n=int(m.group(2)); nn=n+1 if n>=2 else n
    return f'class="kick"{m.group(1)}>{nn:02d} \u00b7 '
s=re.sub(r'class="kick"([^>]*)>(\d+) \u00b7 ', kick_repl, s)

def pnum_repl(m):
    pre=m.group(1); n=int(m.group(2))
    nn = n+1 if 4<=n<=11 else (13 if n==12 else n)
    return f'class="pnum"{pre}>{nn:02d}</div>'
s=re.sub(r'class="pnum"([^>]*)>(\d+)</div>', pnum_repl, s)

# name page block (literal middot chars, double-quoted syllcol args to allow apostrophes)
name_block = '''
# 3b THE NAME / OUR STORY
def _syllcol(imgkey, meaning, desc):
    return f"""<div style="flex:1;text-align:center;padding:0 4mm;">
      <div style="height:30mm;display:flex;align-items:flex-end;justify-content:center;"><img src="{I[imgkey]}" style="height:26mm;"/></div>
      <div class="serif" style="font-weight:600;font-size:17pt;color:{BORDEAUX};margin-top:7mm;">{meaning}</div>
      <p class="body" style="margin:2.5mm auto 0;max-width:72mm;text-align:center;">{desc}</p>
    </div>"""
pages.append(page(f"""<div class="pad">
  <div class="kick">02 \u00b7 The Name</div>
  <h1 class="sec">The name</h1>
  <p class="lead" style="max-width:184mm;">TaMaSha carries its meaning in three syllables - a small story, rooted in Mandarin, of the feminine, the maternal, and the power to clear away what weighs us down.</p>
  <div style="display:flex;gap:6mm;margin-top:11mm;align-items:flex-start;">
    {_syllcol("ta","She / Her","The feminine - grace and welcome held at the heart of the house.")}
    <div style="width:1px;align-self:stretch;background:rgba(191,160,90,.5);"></div>
    {_syllcol("ma","Mother","Nourishment and care - the warmth and generosity of a mother's table.")}
    <div style="width:1px;align-self:stretch;background:rgba(191,160,90,.5);"></div>
    {_syllcol("sha","Remover of negativity","A place that lifts what weighs on you - you leave lighter than you came.")}
  </div>
  <p class="body" style="margin-top:11mm;text-align:center;max-width:180mm;margin-left:auto;margin-right:auto;font-style:italic;">Together, Ta\u00b7Ma\u00b7Sha welcomes you like her, feeds you like a mother, and sends you out a little lighter.</p>
</div><div class="pttl">The Name</div><div class="pnum">04</div>"""))

'''
s=s.replace("# 4 LOGO SIGNATURE", name_block+"# 4 LOGO SIGNATURE",1)

old_tags='tags=["A quiet drama, plated.","Pure veg. Pure Asian. Pure theatre.","Vegetarian, without compromise.","The spectacle of vegetarian Asian."]'
new_tags='tags=["A quiet drama, plated.","She gathers. She nourishes. She lifts.","A mother\'s table, free of the everyday.","Pure veg. Pure Asian. Pure theatre.","Vegetarian, without compromise."]'
assert old_tags in s, "tags anchor missing"
s=s.replace(old_tags,new_tags)
s=s.replace('Primary recommendation: "A quiet drama, plated."',
            'Primary: "A quiet drama, plated." Name-led alternative (see The Name): "She gathers. She nourishes. She lifts."')

# bump version marker
s=s.replace("Brand Book v1.0","Brand Book v2.0").replace("Version 1.0","Version 2.0")

open('build_book.py','w').write(s)
print("patched")
