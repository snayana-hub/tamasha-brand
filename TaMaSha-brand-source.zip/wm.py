# Wordmark -> font-independent SVG paths using fontTools glyph outlines.
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.boundsPen import BoundsPen

def layout(text, font_path, tracking=0.0):
    """Return dict: paths (list of {d, x, char, bounds}), width, upem, ascent, cap, xheight.
    Coordinates in font units, y-up. tracking is fraction of upem added between glyphs."""
    f = TTFont(font_path)
    gs = f.getGlyphSet()
    cmap = f.getBestCmap()
    upem = f['head'].unitsPerEm
    hmtx = f['hmtx']
    os2 = f['OS/2'] if 'OS/2' in f else None
    cap = getattr(os2, 'sCapHeight', 0) or int(upem*0.7)
    xh  = getattr(os2, 'sxHeight', 0) or int(upem*0.5)
    asc = f['hhea'].ascent
    track = tracking*upem
    x = 0.0
    out = []
    for ch in text:
        gname = cmap[ord(ch)]
        pen = SVGPathPen(gs)
        gs[gname].draw(pen)
        d = pen.getCommands()
        bp = BoundsPen(gs)
        gs[gname].draw(bp)
        b = bp.bounds  # (xmin,ymin,xmax,ymax) or None (space)
        adv = hmtx[gname][0]
        out.append({'char':ch,'d':d,'x':x,'adv':adv,'bounds':b})
        x += adv + track
    total = x - track if out else 0
    return {'paths':out,'width':total,'upem':upem,'cap':cap,'xheight':xh,'ascent':asc}

if __name__=='__main__':
    import json,sys
    r=layout('TaMaSha', sys.argv[1], float(sys.argv[2]) if len(sys.argv)>2 else 0.06)
    print('width',r['width'],'upem',r['upem'],'cap',r['cap'],'xh',r['xheight'])
    for p in r['paths']:
        print(p['char'], 'x=%.0f'%p['x'],'adv=%d'%p['adv'],'bounds=',p['bounds'])
